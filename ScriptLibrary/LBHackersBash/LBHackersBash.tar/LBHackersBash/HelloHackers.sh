#! /bin/bash

# You can add comments like this! #

echo "Hello, Hackers-Arise!"
