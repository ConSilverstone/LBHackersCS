#! /bin/bash

echo "Welcome to the world lil guy!"
