#! /bin/bash

## Second ever bash script. User prompts and variables ##
## Get excited!

echo "What is your name?"

read name

echo "What chapter are you in Linux basics for hackers?"

read chapter

echo "Welcome $name to Chapter $chapter of Linux Basics for Hackers!"
